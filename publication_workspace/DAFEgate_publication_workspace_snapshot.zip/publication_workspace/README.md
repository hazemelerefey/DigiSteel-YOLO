# DAFEGate-YOLO Publication Workspace

This folder is the continuation package for converting the DAFEsteel graduation project into a journal manuscript.

## Current source of truth

- `manuscript/DAFEgate_YOLO_Manuscript_Draft_v9_Journal_Style_Compressed.docx`
- `audits/DAFEsteel_publication_audit_v1.md`
- `manifests/DAFEsteel_evidence_matrix_v1.csv`
- `plans/DAFEsteel_Publication_Continuity_and_Hardware_Return_Plan.docx`

## Scientific facts currently locked

- Final DAFEGate v4 observed test result: mAP@0.5 = 81.98%, mAP@0.5:0.95 = 46.80%.
- Clean YOLO11n baseline observed test result: mAP@0.5 = 79.35%, mAP@0.5:0.95 = 45.83%.
- Baseline used Mosaic = 1.0; final v4 used Mosaic = 0.6. The +2.63 percentage-point difference is descriptive, not an isolated architecture effect.
- DAFEGate is code-accurately described as a learnable Sobel-initialized edge representation followed by analytical local variance over that edge representation, channel-selective fusion, and a near-identity additive residual.
- Final DAFEGate input is P3-scale 80 x 80 x 128 under YOLO11n scaling.
- DAFEGate adds 98,817 parameters. Total model: 2,689,827 params and 7.7 GFLOPs.
- Exact realized split: 1,290 train / 344 validation / 166 test.
- Historical 145 FPS claim is not considered publication-verified.

## Work that can continue without GPU

1. Journal-specific formatting after target selection.
2. Scientific writing refinement and citation maintenance.
3. Reproducibility packaging and exact split manifests.
4. Figure polishing for Figures 1-5.
5. Submission metadata and supplementary-material preparation.

## Work to execute when GPU returns

1. Matched YOLO11n baseline vs final DAFEGate v4 with Mosaic = 0.6.
2. Five paired seeds for the primary comparison.
3. Isolated ablations for Sobel initialization, local-variance stage, and SE attention.
4. Regenerate final PR curves, confusion matrices, and qualitative detections.
5. Standardized latency benchmark with explicit timing boundaries.

## Preferred journal strategy

Primary target after controlled validation: Machine Vision and Applications.
Strong backup: Sensors.
Stretch target if repeated-seed and ablation evidence is strong: Scientific Reports.
Conditional real-time target after latency validation: Journal of Real-Time Image Processing.

Do not treat older graduation-report figures or historical summaries as the final publication source when they conflict with the evidence matrix.
