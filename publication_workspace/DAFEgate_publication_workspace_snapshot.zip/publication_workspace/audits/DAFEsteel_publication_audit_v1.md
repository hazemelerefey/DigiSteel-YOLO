# DAFEsteel Publication Forensic Audit v1

**Repository snapshot:** `DAFEsteel-main.zip` uploaded 12 Sep 2026  
**Purpose:** establish a publication-grade source of truth before manuscript drafting.

## Executive verdict

The repository contains enough evidence to verify that the reported **81.978% mAP@0.5** is a real held-out test result produced by the run `dafegate_v4_20260726_0941`. However, the current graduation-report narrative overstates how controlled the baseline comparison is and misdescribes parts of the final architecture. The manuscript should not be finalized until these issues are corrected experimentally and textually.

### Highest-priority findings

1. **Final implementation is not a pair of independent parallel edge/texture branches.** All inspected canonical/final implementations compute `edge_feat = edge_branch(x)` and then `texture_feat = texture_branch(edge_feat)`. The variance branch is therefore **edge-conditioned**.
2. **P3 has 128 channels in the final YOLO11n-scaled model, not 256.** The exact DAFEGate parameter count is 98,817 at C=128, matching the model summary.
3. **The +2.63 percentage-point gain is not yet an architecture-only controlled comparison.** The clean baseline uses `mosaic=1.0`; final DAFEGate v4 uses `mosaic=0.6`.
4. **The final test metric itself is well-provenanced.** The notebook, evaluation JSON, and checkpoint run identity agree on mAP@0.5=0.819780..., mAP@0.5:0.95=0.468038, P=0.725483, R=0.797902.
5. **Single-seed evidence is insufficient for publication-grade statistical claims.** Both principal runs use seed 42.
6. **Current PR curve/confusion matrix are historical artifacts, not final-v4 artifacts.** They must be regenerated or omitted.
7. **145 FPS is not currently supported by a reproducible final benchmark in the repository.** Final notebook timing implies different speeds depending on timing boundary. A standardized benchmark is required.
8. **Compute overhead is materially larger than parameter overhead.** Params increase 3.81%, but model GFLOPs rise from 6.4 to 7.7 (~20.3%).
9. **Dataset split regeneration is not fully deterministic.** `tools/prepare_datasets.py` uses Python's process-randomized `hash()` in the split seed. The exact 1290/344/166 split should be frozen as manifests.
10. **Several claimed component-wise ablation gains are not isolated causal ablations.** v3→v4 changes multiple factors simultaneously.

---

## Verified final model evidence

### DAFEGate v4

- Run: `dafegate_v4_20260726_0941`
- Checkpoint: `dafegate/runs/best.pt`
- Ultralytics: 8.4.95
- PyTorch: 2.6.0+cu124
- GPU: NVIDIA RTX 2000 Ada Generation, 16 GB
- Input: 640
- Batch: 32
- Optimizer: AdamW
- lr0: 0.001
- lrf: 0.01
- Seed: 42
- Mosaic: 0.6
- MixUp: 0.05
- Patience: 80
- Maximum epochs: 400
- Early stopped after 351 epochs; best epoch 271
- Test images: 166
- Parameters: 2,689,827
- GFLOPs: 7.7

### Exact final test metrics

| Metric | Value |
|---|---:|
| mAP@0.5 | 0.8197803748 |
| mAP@0.5:0.95 | 0.4680376392 |
| Precision | 0.7254831983 |
| Recall | 0.7979015686 |

Per-class AP@0.5:

| Class | AP@0.5 |
|---|---:|
| Crazing | 0.4912205 |
| Inclusion | 0.8828550 |
| Patches | 0.9173527 |
| Pitted surface | 0.8502209 |
| Rolled-in scale | 0.7883584 |
| Scratches | 0.9886748 |

Primary evidence:
- `notebooks/exp_dafegate_evaluation.ipynb`
- `evals/dafegate_v4_20260726_0941_summary.json`
- `dafegate/evals/dafegate_v4_summary.json`
- `dafegate/runs/best.pt`

---

## Verified clean baseline evidence

- Run: `final_baseline_v1_20260725_1328`
- Input: 640
- Batch: 32
- Optimizer: AdamW
- Seed: 42
- **Mosaic: 1.0**
- MixUp: 0.05
- Best epoch: 231
- Stopped after 311 epochs
- Parameters: 2,591,010
- GFLOPs: 6.4

| Metric | Value |
|---|---:|
| mAP@0.5 | 0.7934713601 |
| mAP@0.5:0.95 | 0.4582706634 |
| Precision | 0.7414618969 |
| Recall | 0.7624323628 |

Primary evidence:
- `notebooks/week4_fresh_baseline.ipynb`
- `evals/final_baseline_v1_20260725_1328_summary.json`

### Publication implication

The numerical delta is approximately +2.63 pp at mAP@0.5, but it **cannot yet be described as the isolated effect of DAFEGate**, because the augmentation policy differs (`mosaic=1.0` baseline vs `0.6` v4).

---

## Architecture correction

### What the final code actually computes

```text
x
 └─> EdgeBranch(x) = E
      └─> TextureBranch(E) = T  [local variance of edge-aware features]

Concat(E, T) -> SE attention -> fusion -> h

y = x + sigmoid(alpha_raw) * h
```

This differs from the parallel diagram currently used in reports:

```text
EdgeBranch(x)
TextureBranch(x)
```

Relevant implementation paths:
- `digisteel/modules/dafe.py`
- `dafegate/modules/dafe.py`
- `submission_package/03_Model_Architecture_and_Configs/dafe.py`
- `huggingface_space/dafegate/modules/dafe.py`

All inspected variants use `texture_branch(edge_feat)`.

### Correct P3 dimensions

For the final YOLO11n nano scaling:

- P3 spatial resolution: 80 × 80 at 640 input
- P3 channels: **128**
- DAFEGate trainable parameters: **98,817**

Component parameter reconstruction at C=128:

| Component | Parameters |
|---|---:|
| Edge branch | 73,856 |
| Texture branch | 4,224 |
| Fusion | 16,640 |
| SE attention | 4,096 |
| Residual scalar | 1 |
| **Total** | **98,817** |

### Residual-gradient correction

For

`y = x + alpha h(x)`

The total derivative is

`dy/dx = I + alpha * dh(x)/dx`

The defensible statement is that the additive formulation preserves an **explicit identity gradient path**; it is not correct to say the total derivative is always 1.

---

## Dataset/reproducibility findings

Verified EDA:

- 1,800 images
- 4,189 annotations
- split: 1,290 train / 344 val / 166 test
- class counts: inclusion 1011, patches 881, crazing 689, rolled-in scale 628, scratches 548, pitted surface 432
- least frequent class: **pitted surface**
- hardest baseline class: **crazing**
- exact duplicate image groups: 1
- edge-touching boxes: 56.58%
- blurry images: 5.0%
- out-of-bounds annotations: 0

Primary evidence:
- `evals/eda_results.json`
- `experiments/17_eda_v1/results/eda_annotations.csv`

### Split reproducibility risk

`tools/prepare_datasets.py` uses a split seed involving Python's built-in `hash(filename)`. Python hash randomization can change across processes unless `PYTHONHASHSEED` is fixed. Therefore seed 42 alone does not fully define the split regeneration procedure.

**Required publication fix:** freeze and publish exact train/val/test image manifests from the already-used split rather than regenerating it procedurally.

Ultralytics logs also report automatic removal of duplicate label rows in three files. This should be explicitly documented or the labels should be cleaned and the experiment rerun.

---

## Efficiency/FPS audit

The repository currently does not contain a clear final benchmark reproducing the claimed **145 FPS** under a documented timing boundary.

Final-v4 notebook test timing reports approximately:
- preprocess: 2.3 ms/image
- inference: 4.9 ms/image
- postprocess: 0.9 ms/image

Depending on whether FPS is defined as inference-only or end-to-end, these imply materially different throughput values. Therefore 145 FPS must be treated as **unverified for publication** until a standardized benchmark is rerun.

Recommended benchmark report:
- exact GPU/device/runtime
- input 640
- batch 1
- FP32 and FP16 separately
- warm-up iterations
- >= 500 timed iterations
- model-only latency and full preprocessing+NMS latency
- mean, median, p95
- identical protocol for baseline and DAFEGate

---

## Ablation audit

The repository contains an architectural evolution sequence, but several reported component-wise gains are not supported by isolated experiments. The transition into final v4 changes several factors at once, including residual form, capacity, attention, and placement.

For publication, distinguish:

- **architectural evolution table**: historical v1/v2/v3/v4 runs
- **true isolated ablation table**: newly controlled experiments varying one factor at a time

Do not assign a numeric gain to Sobel initialization, SE, P3-only placement, residual form, or C/2 capacity unless the corresponding isolated run exists.

---

## Required publication experiment plan

Priority order:

1. Freeze exact dataset manifests and clean/document duplicate labels.
2. Re-run **clean YOLO11n baseline and final DAFEGate under identical hyperparameters**, including mosaic=0.6.
3. Use at least **5 paired random seeds** for both models.
4. Report mean ± SD, paired per-seed deltas, 95% CI; consider paired significance testing.
5. Run minimal isolated ablations:
   - baseline
   - edge branch only
   - edge branch with random initialization vs Sobel initialization
   - edge + edge-conditioned local variance
   - SE on/off
   - additive residual vs chosen comparator
   - P3 vs relevant placement alternative
6. Regenerate final PR curve, raw and normalized confusion matrices, per-class plots, and qualitative error cases from the final controlled checkpoint(s).
7. Rebenchmark parameters, GFLOPs, latency, and FPS under one documented protocol.
8. Only then lock Methods, Results, and the abstract's quantitative claims.

---

## Manuscript wording decisions already locked

Avoid these claims unless new evidence is produced:

- “The +2.63 pp gain is solely due to DAFEGate.”
- “The texture and edge branches operate independently in parallel.”
- “P3 has 256 channels.”
- “The additive residual always has derivative 1.”
- “145 FPS is a verified device-independent speed.”
- “Each v4 design component contributed a specific fraction of the gain.”
- “The method is statistically superior” based on the single seed.

Currently defensible wording:

> The archived final run of DAFEGate-YOLO achieved 81.98% mAP@0.5 on the documented 166-image NEU-DET test split. The implementation applies a learnable edge-enhancement branch followed by an edge-conditioned local-variance representation, channel-selective fusion, and a near-identity additive residual at P3. A publication-grade causal comparison against YOLO11n still requires retraining both models under an identical augmentation policy and repeated paired seeds.

---

## Repository audit status

- Repository fully extracted and indexed: **331 files / 79 directories**.
- High-priority executable/code/config/evaluation/notebook/report paths inspected.
- Checkpoint metadata inspected without executing untrusted pickle payloads.
- Remaining second-pass work: figure/image provenance, bundled reference-PDF cross-checks, notebook-by-notebook historical experiment matrix, and full literature-claim verification against original publications.

This document is an **initial forensic audit**, not the final manuscript.
